package InventoryAndSchedulingSystem;

public class ViewAdminAccount extends javax.swing.JFrame {

    public ViewAdminAccount() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        whole_Panel = new javax.swing.JPanel();
        adminAccount_ScrollPane = new javax.swing.JScrollPane();
        adminAccount_Table = new javax.swing.JTable();
        accountNumber_Label = new javax.swing.JLabel();
        accountNumber_TextField = new javax.swing.JTextField();
        email_Label = new javax.swing.JLabel();
        email_TextField1 = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_Icon = new javax.swing.JLabel();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TexField = new javax.swing.JTextField();
        top_Panel = new javax.swing.JPanel();
        clientShop_Logo = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        adminAccount_Label = new javax.swing.JLabel();
        add_Button = new javax.swing.JButton();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        view_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN ACCOUNT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        adminAccount_Table.setForeground(new java.awt.Color(255, 255, 255));
        adminAccount_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Account Number", "Email", "Username", "Password", "Phone Number"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminAccount_Table.getTableHeader().setReorderingAllowed(false);
        adminAccount_ScrollPane.setViewportView(adminAccount_Table);
        if (adminAccount_Table.getColumnModel().getColumnCount() > 0) {
            adminAccount_Table.getColumnModel().getColumn(0).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(1).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(2).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(3).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(4).setResizable(false);
        }

        whole_Panel.add(adminAccount_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, 570, 360));

        accountNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accountNumber_Label.setText("Account Number");
        whole_Panel.add(accountNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));
        whole_Panel.add(accountNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 200, 35));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));
        whole_Panel.add(email_TextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 200, 35));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 200, 35));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 200, 35));

        showPassword_Icon.setForeground(new java.awt.Color(255, 255, 255));
        showPassword_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyecrosssed.png"))); // NOI18N
        whole_Panel.add(showPassword_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 330, -1, 50));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, -1, -1));
        whole_Panel.add(phoneNumber_TexField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 200, 35));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        adminAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        adminAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        adminAccount_Label.setText("Admin Account");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(adminAccount_Label)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 488, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(17, 17, 17))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(adminAccount_Label))
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(clientShop_Logo)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 90));

        add_Button.setText("Add Account ");
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 470, -1, -1));

        edit_Button.setText("Edit Account");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(edit_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 470, -1, -1));

        delete_Button.setText("Delete Account ");
        whole_Panel.add(delete_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, -1, -1));

        view_Button.setText("View Account ");
        view_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(view_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 470, -1, -1));

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });
        whole_Panel.add(logout_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 470, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
       AddAccount addAccountModule = new AddAccount();
       addAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
       EditAccount editAccountModule = new EditAccount();
       editAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void view_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_ButtonActionPerformed
        ViewAccount viewAccountModule = new ViewAccount();
        viewAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_view_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
       Login loginModule = new Login();
       loginModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_logout_IconMouseClicked


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewAdminAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel accountNumber_Label;
    private javax.swing.JTextField accountNumber_TextField;
    private javax.swing.JButton add_Button;
    private javax.swing.JLabel adminAccount_Label;
    private javax.swing.JScrollPane adminAccount_ScrollPane;
    private javax.swing.JTable adminAccount_Table;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JButton delete_Button;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TexField;
    private javax.swing.JLabel showPassword_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    private javax.swing.JButton view_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
