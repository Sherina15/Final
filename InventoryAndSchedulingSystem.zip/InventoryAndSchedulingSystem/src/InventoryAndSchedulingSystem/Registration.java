package InventoryAndSchedulingSystem;


public class Registration extends javax.swing.JFrame {

    public Registration() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        left_Panel = new javax.swing.JPanel();
        right_Panel = new javax.swing.JPanel();
        registration_Label = new javax.swing.JLabel();
        greetings_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        email_Icon = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_Icon = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        key_Icon = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_Icon = new javax.swing.JLabel();
        confirmPassword_Label = new javax.swing.JLabel();
        check_Icon = new javax.swing.JLabel();
        confirmPassword_Field = new javax.swing.JPasswordField();
        confirmShowPassword_Icon = new javax.swing.JLabel();
        phoneNumber_Label = new javax.swing.JLabel();
        phone_Icon = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        register_Button = new javax.swing.JButton();
        signIn_Label_Button = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("REGISTRATION");

        left_Panel.setBackground(new java.awt.Color(0, 0, 0));
        left_Panel.setPreferredSize(new java.awt.Dimension(800, 600));

        right_Panel.setBackground(new java.awt.Color(255, 255, 255));

        registration_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        registration_Label.setText("REGISTRATION");

        greetings_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        greetings_Label.setText("LET'S GET STARTED ");

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");

        email_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_envelope.png"))); // NOI18N

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");

        username_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_username.png"))); // NOI18N

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");

        key_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_key.png"))); // NOI18N

        showPassword_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyecrosssed.png"))); // NOI18N

        confirmPassword_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        confirmPassword_Label.setText("Confirm Password");

        check_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_check.png"))); // NOI18N

        confirmShowPassword_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyecrosssed.png"))); // NOI18N

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number");

        phone_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N

        register_Button.setBackground(new java.awt.Color(0, 0, 0));
        register_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        register_Button.setForeground(new java.awt.Color(255, 255, 255));
        register_Button.setText("REGISTER");

        signIn_Label_Button.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        signIn_Label_Button.setText("Already have an account? Sign In");
        signIn_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signIn_Label_ButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout right_PanelLayout = new javax.swing.GroupLayout(right_Panel);
        right_Panel.setLayout(right_PanelLayout);
        right_PanelLayout.setHorizontalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(right_PanelLayout.createSequentialGroup()
                        .addComponent(registration_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(right_PanelLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(username_Label)
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addComponent(email_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addComponent(username_Icon)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(password_Label)
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addComponent(key_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(password_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(showPassword_Icon))
                            .addComponent(confirmPassword_Label)
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addComponent(check_Icon)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(confirmPassword_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(confirmShowPassword_Icon))
                            .addComponent(phoneNumber_Label)
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addComponent(phone_Icon)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, right_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                        .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(greetings_Label)
                            .addComponent(email_Label))
                        .addGap(224, 224, 224))))
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(register_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(signIn_Label_Button)
                .addContainerGap(105, Short.MAX_VALUE))
        );
        right_PanelLayout.setVerticalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(registration_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(greetings_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(email_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(showPassword_Icon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(password_Field, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(key_Icon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addComponent(confirmPassword_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(confirmShowPassword_Icon, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(confirmPassword_Field)
                    .addComponent(check_Icon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(phone_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(register_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(signIn_Label_Button)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        clientShop_Logo.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientShop_Name.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo)
                    .addComponent(clientShop_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(right_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(clientShop_Logo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(clientShop_Name)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(right_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void signIn_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signIn_Label_ButtonMouseClicked
       Login loginModule = new Login();
       loginModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_signIn_Label_ButtonMouseClicked

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel check_Icon;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JPasswordField confirmPassword_Field;
    private javax.swing.JLabel confirmPassword_Label;
    private javax.swing.JLabel confirmShowPassword_Icon;
    private javax.swing.JLabel email_Icon;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel greetings_Label;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JLabel key_Icon;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel phone_Icon;
    private javax.swing.JButton register_Button;
    private javax.swing.JLabel registration_Label;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel showPassword_Icon;
    private javax.swing.JLabel signIn_Label_Button;
    private javax.swing.JLabel username_Icon;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
