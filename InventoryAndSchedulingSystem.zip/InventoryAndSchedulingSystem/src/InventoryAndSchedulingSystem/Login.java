package InventoryAndSchedulingSystem;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        right_Panel = new javax.swing.JPanel();
        left_Panel = new javax.swing.JPanel();
        login_Label = new javax.swing.JLabel();
        greetings_Label = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        profile_Icon = new javax.swing.JLabel();
        line1_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        lock_Icon = new javax.swing.JLabel();
        line2_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_Icon = new javax.swing.JLabel();
        login_Button = new javax.swing.JButton();
        signup_Label_Button = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");

        right_Panel.setBackground(new java.awt.Color(0, 0, 0));

        left_Panel.setBackground(new java.awt.Color(255, 255, 255));

        login_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        login_Label.setText("LOGIN");
        login_Label.setToolTipText("");

        greetings_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        greetings_Label.setText("HEY, WELCOME");

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        username_Label.setText("Username");

        profile_Icon.setForeground(new java.awt.Color(255, 255, 255));
        profile_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_user.png"))); // NOI18N

        line1_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        line1_Label.setText("____________________________________________");

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_TextField.setBorder(null);
        username_TextField.setDragEnabled(true);

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        password_Label.setText("Password");

        lock_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_lock.png"))); // NOI18N
        lock_Icon.setToolTipText("");

        line2_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        line2_Label.setText("____________________________________________");

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Field.setBorder(null);
        password_Field.setDragEnabled(true);

        showPassword_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyecrosssed.png"))); // NOI18N

        login_Button.setBackground(new java.awt.Color(0, 0, 0));
        login_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        login_Button.setForeground(new java.awt.Color(255, 255, 255));
        login_Button.setText("LOGIN");
        login_Button.setToolTipText("click Login");
        login_Button.setBorder(null);
        login_Button.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        login_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_ButtonActionPerformed(evt);
            }
        });

        signup_Label_Button.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        signup_Label_Button.setText("Don't have an account? Sign Up");
        signup_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signup_Label_ButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(profile_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(line1_Label, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE))
                .addGap(57, 57, 57))
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(left_PanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(password_Label)
                            .addComponent(username_Label)
                            .addGroup(left_PanelLayout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(login_Label))
                            .addComponent(greetings_Label)))
                    .addGroup(left_PanelLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(login_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(left_PanelLayout.createSequentialGroup()
                                .addComponent(lock_Icon)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(line2_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(password_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(showPassword_Icon)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, left_PanelLayout.createSequentialGroup()
                .addContainerGap(108, Short.MAX_VALUE)
                .addComponent(signup_Label_Button)
                .addGap(96, 96, 96))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(login_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(greetings_Label)
                .addGap(37, 37, 37)
                .addComponent(username_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(line1_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(profile_Icon)
                        .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24)
                .addComponent(password_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(line2_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(showPassword_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(lock_Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(password_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(login_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(signup_Label_Button)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        clientShop_Logo.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientShop_Name.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        javax.swing.GroupLayout right_PanelLayout = new javax.swing.GroupLayout(right_Panel);
        right_Panel.setLayout(right_PanelLayout);
        right_PanelLayout.setHorizontalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo)
                    .addComponent(clientShop_Name))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        right_PanelLayout.setVerticalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(clientShop_Logo)
                .addGap(18, 18, 18)
                .addComponent(clientShop_Name)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(left_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(right_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(right_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void login_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_ButtonActionPerformed
        Menu menuSystemModule = new Menu();
        menuSystemModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_login_ButtonActionPerformed

    private void signup_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signup_Label_ButtonMouseClicked
        Registration registrationModule = new Registration();
        registrationModule.setVisible(true);
        dispose();      
    }//GEN-LAST:event_signup_Label_ButtonMouseClicked


    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JLabel greetings_Label;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JLabel line1_Label;
    private javax.swing.JLabel line2_Label;
    private javax.swing.JLabel lock_Icon;
    private javax.swing.JButton login_Button;
    private javax.swing.JLabel login_Label;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel profile_Icon;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel showPassword_Icon;
    private javax.swing.JLabel signup_Label_Button;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
