package InventoryAndSchedulingSystem;

public class AddProduct extends javax.swing.JFrame {


    public AddProduct() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        addProduct_Label = new javax.swing.JLabel();
        lower_Panel = new javax.swing.JPanel();
        productName_Label = new javax.swing.JLabel();
        productName_TextField = new javax.swing.JTextField();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        quantity_Label = new javax.swing.JLabel();
        quantity_Spinner = new javax.swing.JSpinner();
        category_Label = new javax.swing.JLabel();
        category_ComboBox = new javax.swing.JComboBox<>();
        add_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD PRODUCT");

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        addProduct_Label.setBackground(new java.awt.Color(0, 0, 0));
        addProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        addProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        addProduct_Label.setText("ADD PRODUCT");

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));

        productName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productName_Label.setText("Product Name");

        productName_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productName_TextFieldActionPerformed(evt);
            }
        });

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");

        price_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                price_TextFieldActionPerformed(evt);
            }
        });

        quantity_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantity_Label.setText("Quantity");

        category_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        category_Label.setText("Category");

        category_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        add_Button.setText("Add");
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lower_PanelLayout = new javax.swing.GroupLayout(lower_Panel);
        lower_Panel.setLayout(lower_PanelLayout);
        lower_PanelLayout.setHorizontalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(productName_Label)
                        .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(price_Label)
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(quantity_Label)
                        .addComponent(quantity_Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(category_Label)
                        .addComponent(category_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(109, Short.MAX_VALUE))
        );
        lower_PanelLayout.setVerticalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(productName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(price_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quantity_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quantity_Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(category_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(category_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(add_Button)
                .addGap(0, 58, Short.MAX_VALUE))
        );

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(addProduct_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(16, 16, 16))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addGap(18, 18, 18)
                        .addComponent(addProduct_Label))
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 450, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void productName_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productName_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_productName_TextFieldActionPerformed

    private void price_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_price_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_price_TextFieldActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        ViewProduct viewProductModule = new ViewProduct();
        viewProductModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_add_ButtonActionPerformed


    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addProduct_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JComboBox<String> category_ComboBox;
    private javax.swing.JLabel category_Label;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JLabel productName_Label;
    private javax.swing.JTextField productName_TextField;
    private javax.swing.JLabel quantity_Label;
    private javax.swing.JSpinner quantity_Spinner;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
