package InventoryAndSchedulingSystem;

public class AppointmentReport extends javax.swing.JFrame {


    public AppointmentReport() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        appointmentReport_Label = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        appointmentReport_ScrollPane = new javax.swing.JScrollPane();
        appointmentReport_Table = new javax.swing.JTable();
        clearData_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("APPOINTMENT REPORT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        appointmentReport_Label.setText("Appointment Report");
        appointmentReport_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        appointmentReport_Label.setForeground(new java.awt.Color(255, 255, 255));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(appointmentReport_Label)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(appointmentReport_Label)
                        .addGap(0, 5, Short.MAX_VALUE)))
                .addContainerGap())
        );

        appointmentReport_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Reservation No.", "Owner's Name", "Pet's Name ", "Contact No.", "Pet's Size", "Service", "Date", "Time ", "Price"
            }
        ));
        appointmentReport_ScrollPane.setViewportView(appointmentReport_Table);

        clearData_Button.setText("Clear All Data");

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(top_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(appointmentReport_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 900, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(clearData_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logout_Icon)
                        .addGap(22, 22, 22))))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(appointmentReport_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearData_Button)
                    .addComponent(logout_Icon))
                .addGap(0, 18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
       Menu menuModule = new Menu();
       menuModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppointmentReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel appointmentReport_Label;
    private javax.swing.JScrollPane appointmentReport_ScrollPane;
    private javax.swing.JTable appointmentReport_Table;
    private javax.swing.JButton back_Button;
    private javax.swing.JButton clearData_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
